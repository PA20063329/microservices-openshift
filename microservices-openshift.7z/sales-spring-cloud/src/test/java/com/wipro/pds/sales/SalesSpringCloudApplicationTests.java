package com.wipro.pds.sales;

//@RunWith(SpringRunner.class)
//@SpringBootTest
public class SalesSpringCloudApplicationTests {

	//@Test
	public void contextLoads() {
		
		/*logger.info( "Operation Determine Price for a Flight" );
		Itinerary itinerary = SalesTicketingService.price( flight );
		logger.info("Priced ticket at " + itinerary.getPrice() );
		*/
	}

}
