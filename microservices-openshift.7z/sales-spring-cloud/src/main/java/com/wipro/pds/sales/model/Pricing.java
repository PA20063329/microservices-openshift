package com.wipro.pds.sales.model;

public class Pricing
{
	public int flightNumber;
	public int basePrice;
	public int[] availability;//percent available at date offset
}