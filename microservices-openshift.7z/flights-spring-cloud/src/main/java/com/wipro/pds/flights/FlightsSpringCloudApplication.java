package com.wipro.pds.flights;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlightsSpringCloudApplication {

	public static void main(String[] args) {
		SpringApplication.run(FlightsSpringCloudApplication.class, args);
	}

}
