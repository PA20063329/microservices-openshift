package com.wipro.pds.airports;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AirportsSpringCloudApplication {

	public static void main(String[] args) {
		SpringApplication.run(AirportsSpringCloudApplication.class, args);
	}

}
